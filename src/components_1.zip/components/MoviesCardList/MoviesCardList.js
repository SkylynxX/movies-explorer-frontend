import React, {useEffect, useState} from "react";
import MoviesCard from "../MoviesCard/MoviesCard";
import "./MoviesCardList.css";
import filmImg from "../../images/film.png";

export default function MoviesCardList({ isSaved, movies, isProcessed }) {
  const [isRequestExecuted,setRequestExecuted] = useState(false);
  useEffect(() => {
    if (isProcessed) {
      setRequestExecuted(true);
    }
  }, [isProcessed]);
  return (
    <section className={`movies-card-list ${isProcessed ? "movies-card-list_none" : ""}`} >
      <ul className="movies-card-list__container">
        {movies.map((item, i) => {
          return (
            <MoviesCard
              key={item.id}
              name= {item.nameRU}
              duration={item.duration}
              isSaved={true}
              isLiked={false}
              filmImg={`https://api.nomoreparties.co${item.image.url}`}
            />
          );
        })}
      </ul>
      <div>{!isProcessed && !movies.length && ((isRequestExecuted ? "По Вашему завпросу фильмы не найдены. " : "") + "Ввeдите запрос(не пустую строку) в поисковую строку и нажмите на кнопу \"Найти\" для отображения фильмов. Для отображения короткометражных фильмов устновите значение переключателя \"Короткометражки\" перед отправкой запроса.")}</div>
      <button
        className={`movies-card-list__more-button  ${
          isSaved ? "movies-card-list__more-button_disable" : ""
        }`}
        type="button"
      >
        Ещё
      </button>
    </section>
  );
}

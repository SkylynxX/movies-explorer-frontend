import React, { useState, useEffect } from "react";
import { Route, Switch, useHistory } from "react-router-dom";

import Main from "../Main/Main";
import { CurrentUserContext } from "../../contexts/CurrentUserContext";
import Header from "../Header/Header";
import Footer from "../Footer/Footer";
import Register from "../Register/Register";
import Login from "../Login/Login";
import Profile from "../Profile/Profile";
import Error404 from "../Error404/Error404";
import Movies from "../Movies/Movies";
import SavedMovies from "../SavedMovies/SavedMovies";
import mainAPI from "../../utils/MainApi";
import moviesAPI from "../../utils/MoviesApi";

import "./App.css";

function App() {
  const [currentUser, setCurrentUser] = useState({});
  let movies = [];
  // let _searchRequest;
  const [filteredMovies, setFilteredMovies] = useState([]);
  const [isSearchShortMovie, setSearchShortMovie] = useState(false);
  const [savedMovies, setSavedMovies] = useState([]);
  const [isLoggedIn, setLoggedIn] = useState(false);
  const [isRequestProcessed, setRequestProcessed] = useState(false);
  const [isRequestSuccess, setRequestSuccess] = useState(false);
  const history = useHistory();
  const current = history.location.pathname;

  useEffect(() => {
    //валидируем токен через API авторизации
    const userToken = localStorage.getItem("jwt");
    if (userToken) {
      mainAPI
        .validateToken(userToken)
        .then((userData) => {
          if (userData) {
            // console.log(userData)
            setLoggedIn(true);
            history.push("/");
          }
        })
        .catch((err) => {
          //попадаем сюда если один из промисов завершится ошибкой
          console.log(err);
        });
    }
  }, [history]);

  useEffect(() => {
    mainAPI
      .getUserInfo()
      .then((rxUserInfo) => {
        setCurrentUser(rxUserInfo);
      })
      .catch((err) => {
        //попадаем сюда если промис завершится ошибкой
        console.log(err);
      });
  }, [isLoggedIn]);

  useEffect(() => {
    if (isLoggedIn && !savedMovies.length) {
      setRequestProcessed(true);
      setRequestSuccess(true);
      mainAPI
        .getSavedMovies()
        .then((rxSavedMovies) => {
          setSavedMovies(rxSavedMovies); 
          setRequestProcessed(false);
          setRequestSuccess(true);
        })
        .catch((err) => {
          setRequestSuccess(false);
          setRequestProcessed(false);
          //попадаем сюда если промис завершится ошибкой
          console.log(err);
        });
    }
  }, [isLoggedIn]);

  function filterMovies(searchRequest) {
    console.log(searchRequest);
    let filterRes = []
    if (searchRequest) {
      filterRes = movies.filter((item) => { return ((item.nameRU.toLowerCase().indexOf(searchRequest.toLowerCase()) > -1)
       && (isSearchShortMovie ?  item.duration <= 40 : true))  });
    }
     console.log(filterRes);
    setFilteredMovies(filterRes);
  }

  function getMovies(searchRequest) {
    if (current === "/movies" && !movies.length) {
      setRequestSuccess(false);
      setRequestProcessed(true);
      moviesAPI
        .getInitialMoviess()
        .then((rxMovies) => {
          movies  = rxMovies; //все данные получены, отрисовываем страницу
          filterMovies(searchRequest);
          setRequestSuccess(true);
          setRequestProcessed(false);
          console.log('end');
        })
        .catch((err) => {
          setRequestSuccess(false);
          setRequestProcessed(false);
          //попадаем сюда если промис завершится ошибкой
          console.log(err);
        });
    } else if (current === "/movies") {
      setRequestSuccess(false);
      setRequestProcessed(true);
      filterMovies(searchRequest);
      setRequestSuccess(true);
      setRequestProcessed(false);
    }
  }

  function searchMoviesCallback(searchRequest) {
    if (current === "/movies") {
      getMovies(searchRequest);
    }
  }

  function toggleSearchShortMovieHandler() {
    setSearchShortMovie(!isSearchShortMovie);
  }

  function redirectToSignIn() {
    handleSignOut();
    history.push("/signin");
  }

  function handleSignUp(userData) {
    setRequestSuccess(false);
    setRequestProcessed(true);
    mainAPI
      .signUp(userData)
      .then((userData) => {
      setRequestSuccess(true);
      setRequestProcessed(false);
        //Ждем 5 секунды чтобы дать человеку прочитать что у него всё получилось
        setTimeout(redirectToSignIn, 5000);
      })
      .catch((err) => {
        //В случае не успешной регистрации показываем окно не успеха
      setRequestSuccess(false);
      setRequestProcessed(false);
        console.log(err);
      });
  }

  function handleSignIn(userData) {
    // console.log(userData);
    setRequestProcessed(true);
    setRequestSuccess(false);
    mainAPI
      .signIn(userData)
      .then((userReceivedData) => {
        console.log(userReceivedData);
        //В случае успешной авторизации
        localStorage.setItem("jwt", userReceivedData.token);
        setRequestSuccess(true);
        setRequestProcessed(false);
        setLoggedIn(true);
        history.push("/");
      })
      .catch((err) => {
        //В случае не успешной авторизации показываем окно не успеха
        setRequestSuccess(false);
        setRequestProcessed(false);
        console.log(err);
      });
  }

  function handleUpdateUser(userData) {
    // console.log(userData);
    setRequestProcessed(true);
    setRequestSuccess(false);
    mainAPI
      .setUserInfo(userData)
      .then((userReceivedData) => {
        console.log(userReceivedData);
        //В случае успешной авторизации
        setRequestSuccess(true);
        setRequestProcessed(false);
        setTimeout(redirectToSignIn, 5000);
      })
      .catch((err) => {
        //В случае не успешной авторизации показываем окно не успеха
        setRequestSuccess(false);
        setRequestProcessed(false);
        console.log(err);
      });
  }

  function handleSignOut() {
    localStorage.removeItem("jwt");
    setSavedMovies([]);
    setLoggedIn(false);

  }

  function handleMovieSave(movie) {
    // Снова проверяем, есть ли уже лайк на этой карточке
    // const isLiked = card.likes.some((i) => i === currentUser._id);
    // Отправляем запрос в API и получаем обновлённые данные карточки
    // mainAPI
    //   .changeLikeCardStatus(card._id, !isLiked)
    //   .then((newCard) => {
    //     setCards((state) =>
    //       state.map((c) => (c._id === card._id ? newCard : c))
    //     );
    //   })
    //   .catch((err) => {
    //     console.log(err);
    //   });
  }

  function handleMovieDelete(card) {
    //console.log('delete card enter');
    // mainAPI
    //   .removeCard(card._id)
    //   .then(() => {
    //     setCards((state) => state.filter((item) => item !== card));
    //   })
    //   .catch((err) => {
    //     console.log(err);
    //   });
  }

  return (
    <CurrentUserContext.Provider value={currentUser}>
      <div className="root">
        <Switch>
          <Route exact path="/">
            <Header color="pink" isLoggedIn={true} />
            <Main />
            <Footer />
          </Route>
          <Route path="/signin">
            <Login  onSignIn={handleSignIn} isProcessed={isRequestProcessed} isRequestSuccess={isRequestSuccess}/>
          </Route>
          <Route path="/signup">
            <Register onSignUp={handleSignUp} isProcessed={isRequestProcessed} isRequestSuccess={isRequestSuccess}/>
          </Route>
          <Route path="/profile">
            <Header color="white" isLoggedIn={isLoggedIn}/>
            <Profile onLogOut={handleSignOut} onUpdate={handleUpdateUser}/>
          </Route>
          <Route path="/movies">
            <Header color="white" isLoggedIn={isLoggedIn} />
            <Movies
              searchMoviesCallback={searchMoviesCallback}
              toggleSearchShortMovieHandler={toggleSearchShortMovieHandler}
              isSearchShortMovie={isSearchShortMovie}
              movies={filteredMovies}
              isProcessed={isRequestProcessed}
              isRequestSuccess={isRequestSuccess}
            />
            <Footer />
          </Route>
          <Route path="/saved-movies">
            <Header color="white" isLoggedIn={isLoggedIn} />
            <SavedMovies
              savedMovies={savedMovies}
              isProcessed={isRequestProcessed}
              isRequestSuccess={isRequestSuccess}
            />
            <Footer />
          </Route>
          <Route path="*">
            <Error404 />
          </Route>
        </Switch>
      </div>
    </CurrentUserContext.Provider>
  );
}

export default App;
